CloudSim - Power Package test with Genetic Algorithm and Fast Up Slow Down implementations
==============

This project is based on CloudSim platform and utilizes power package to test two algorithms to schedule VMs to Hosts. Algortihms are Fast Up Slow Down and Genetic Algorithm. Algorithm implementations can be found in PowerVmAllocationPolicyMigrationFUSD.java and PowerVmAllocationPolicyMigrationGA.java. LrrMc.java and LrrMc_GA.java tests are utilized. 
