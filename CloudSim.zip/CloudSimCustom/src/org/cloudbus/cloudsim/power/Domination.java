package org.cloudbus.cloudsim.power;

public enum Domination {
	True, NoDomination, False
}
