package org.cloudbus.cloudsim.power;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.SortedMap;
import java.util.TreeMap;

import org.cloudbus.cloudsim.CloudletScheduler;
import org.cloudbus.cloudsim.CloudletSchedulerDynamicWorkload;
import org.cloudbus.cloudsim.CloudletSchedulerSpaceShared;
import org.cloudbus.cloudsim.CloudletSchedulerTimeShared;
import org.cloudbus.cloudsim.Datacenter;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Host.hostType;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmScheduler;
import org.cloudbus.cloudsim.VmSchedulerSpaceShared;
import org.cloudbus.cloudsim.VmSchedulerTimeShared;
import org.cloudbus.cloudsim.VmSchedulerTimeSharedOverSubscription;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;

public class MultiGA implements Cloneable
{
	double hot=.95,cold=.60;
	
	List<PowerHost> hosts, originalHosts;
	List<PowerVm> vmList, originalVMs;
	Random rnd;
	PowerVmAllocationPolicyMigrationMGA mGA;
	// int[] genotype;
	//SortedMap<Integer, PowerHost> gen;
	int geneSize;
	double[] fitness;

	int id;
	public static int    SA_NUMBER_OF_NEIGHBORHOOD_SEARCHES = 50;
	
	public Object clone() throws CloneNotSupportedException
	{
		return super.clone();
	}

	public MultiGA(PowerVmAllocationPolicyMigrationMGA mGA,List<PowerHost> originalHosts1,int id1) throws Exception
	{
		
		this.mGA=mGA;
		id=id1;
		fitness=new double[] {0.,0.,0.,0.,0.,0.};
		originalHosts=originalHosts1;
		//System.out.println("Number of host in System "+originalHosts1.size());
		this.hosts=new ArrayList<PowerHost>();
		originalVMs=new ArrayList<PowerVm>();
		vmList=new ArrayList<PowerVm>();
		//gen=new TreeMap<>();
		
		for(PowerHost ph:originalHosts)
		{
			if(ph.getMipsUtilization()==0)
			{
				System.out.println("inside");
				continue;
			}
			for(PowerVm pv:ph.<PowerVm>getVmList())
			{
				vmList.add(pv);
				originalVMs.add(pv);
				//gen.put(pv.getId(), null);
			}
		}
		//hosts=originalHosts1;
		copyHosts(originalHosts,hosts);
		rnd = PowerVmAllocationPolicyMigrationMGA.rnd;
		int notFindSuitableHostCount=0;
		for (int i = 0; i < vmList.size(); i++)
		{
			PowerVm vm = vmList.get(i);
			PowerHost foundHost;
			while(true)
			{//kashav: find suitable random host
				notFindSuitableHostCount++;
				if(notFindSuitableHostCount>(originalHosts.size()*10))
				{
				//	System.out.println("!!!!!!!!!!!!!!!!!! Not find sutiable mapping !!!!!!!!!!!!!!!!!! ");
					break;
				}
				foundHost = findRandomHost(vm);
				if(isHostRedStateAfterVmAllocation(foundHost,vm))
				{
					//System.out.println(" host is red after vm allocation ");
					continue;
				}
				
				if(assignVMtoHost(vm, foundHost))
				{
					break;
				}
				
			} 
		}
		getFitness();
	}
	public MultiGA(PowerVmAllocationPolicyMigrationMGA CSA,List<PowerVm> originalVMs1,
			List<PowerVm> vmList1,List<PowerHost> originalHosts1,List<PowerHost> hosts1,double [] fitness1)
	{
		this.mGA=CSA;
		rnd = PowerVmAllocationPolicyMigrationMGA.rnd;
		vmList=new ArrayList<PowerVm>();
		this.fitness=fitness1;
		for(Vm vm:vmList1)
		{
			this.vmList.add((PowerVm) vm);
		}
		originalVMs=new ArrayList<PowerVm>();
		for(Vm vm:originalVMs1)
		{
			originalVMs.add((PowerVm) vm);
		}
		hosts=new ArrayList<PowerHost>();
		for(PowerHost ph:hosts1)
		{
			hosts.add(copyHost1(ph));
		}
		originalHosts=new ArrayList<PowerHost>();
		for(PowerHost ph:originalHosts1)
		{
			originalHosts.add(ph);
		}
		//getFitness();
		
	}
	
	

	//constructor for cloning
		private boolean isHostRedStateAfterVmAllocation(PowerHost ph,PowerVm pv)
	{
		boolean redHost=false;
		double mipsUsageAfterVmAllocation=(ph.getTotalMips()-ph.getAvailableMips())+pv.getCurrentRequestedMaxMips();
		double mipsUtilization=mipsUsageAfterVmAllocation/ph.getTotalMips();
		
		for(double mips:pv.getCurrentRequestedMips())
		{
			//System.out.println(mips);
		}
		
		//System.out.println("before Vm create mips"+ph.getMipsUtilization()+" state "+ph.getHostType());
		ph.vmCreate(pv);
		//System.out.println("After Vm create mips"+ph.getMipsUtilization()+" state "+ph.getHostType());
		ph.vmDestroy(pv);
		
		if(mipsUtilization>hot)
		{
			redHost=true;
		}
		return redHost;
	}

	
	public double[] getFitness() 
	{
		
		for (int i = 0; i < fitness.length; i++)
		{
			fitness[i] = 0;
		}
		double utilCPU=0,utilRam=0, utilBw=0, powerUsage=0;
		int countActiveCpu=0,countActiveRAM=0,countActiveBW=0, countActivePowerUsage=0,countWtoP=0;
		double avgutilCPU,avgutilRam, avgutilBw, avgPowerUsage;

		for (PowerHost host : hosts)
		{//[4] power, [3] wtop
			utilCPU=host.getUtilizationMips()/(double)host.getTotalMips();
			if(utilCPU!=0) {countActiveCpu++;}
			utilBw = host.getUtilizationOfBw() / (double) host.getBw();
			if(utilBw!=0) {countActiveBW++;}
			utilRam = host.getUtilizationOfRam() / (double) host.getRam();
			if(utilRam!=0) {countActiveRAM++;}
			powerUsage=host.getPower();
			if(utilCPU!=0) 
			{	
				countActivePowerUsage++;
				fitness[4]+=powerUsage;
				double mipsUtilzation=host.getMipsUtilization();
				double wTOp=mipsUtilzation/powerUsage;
				fitness[3]+=wTOp;
			}
			
         	fitness[0]+=utilCPU;
			fitness[1]+=utilBw;
			fitness[2]+=utilRam;
			
		}
		avgutilCPU=fitness[0] /countActiveCpu; 
		fitness[0]=avgutilCPU;
			
		avgutilBw=fitness[1] /countActiveBW; 
		fitness[1]=avgutilBw;
			
		avgutilRam=fitness[2] /countActiveRAM; 
		fitness[2]=avgutilRam;
		
		
	return fitness;
	}
	
	
	
	//kashav: compare target population

	private PowerHost copyHost(PowerHost powerHost) 
	{
		VmScheduler sch = powerHost.getVmScheduler(), newSch;
		if (sch instanceof VmSchedulerTimeShared)
		{
			newSch = new VmSchedulerTimeShared(powerHost.getPeList());
		} 
		else if (sch instanceof VmSchedulerTimeSharedOverSubscription)
		{
			newSch = new VmSchedulerTimeSharedOverSubscription(
					powerHost.getPeList());
		} 
		else 
		{
			newSch = new VmSchedulerSpaceShared(powerHost.getPeList());
		}

		return new PowerHost(powerHost.getId(), 
							 new RamProvisionerSimple(powerHost.getRam()),
							 new BwProvisionerSimple(powerHost.getBw()),
							 powerHost.getStorage(), 
							 powerHost.getPeList(), 
							 newSch,
							 powerHost.getPowerModel());
	}
	
	public PowerHost copyHost1(PowerHost host) 
	{
		VmScheduler sch = host.getVmScheduler(), newSch;
		if (sch instanceof VmSchedulerTimeShared)
		{
			newSch = new VmSchedulerTimeShared(host.getPeList());
		} 
		else if (sch instanceof VmSchedulerTimeSharedOverSubscription)
		{
			newSch = new VmSchedulerTimeSharedOverSubscription(
					host.getPeList());
		} 
		else 
		{
			newSch = new VmSchedulerSpaceShared(host.getPeList());
		}

		PowerHost newHost= new PowerHost(host.getId(), 
				 new RamProvisionerSimple(host.getRam()),
				 new BwProvisionerSimple(host.getBw()),
				 host.getStorage(), 
				 host.getPeList(), 
				 newSch,
				 host.getPowerModel());

		for(Vm vm:host.getVmList())
		{
			newHost.vmCreate(vm);
		}
		return newHost;
	}
	

	private void copyHosts(List<PowerHost> src, List<PowerHost> target)
	{
		for (PowerHost powerHost : src)
		{
			target.add(copyHost(powerHost));
		}
	}

	
	public boolean assignVMtoHost(PowerVm vm, PowerHost host)
	{
		boolean result;
		Host prevHost = vm.getHost();
		if (prevHost != null) 
		{
			prevHost.vmDestroy(vm);
		//	System.out.println("              vm destroy"+vm.getId()+" on host "+prevHost.getId());
		}
		Log.setDisabled(true);
		if (host.vmCreate(vm)) 
		{
			//gen.put(vm.getId(), host);

			host.updateVmsProcessing(0);
			// genotype[vmID] = host.getId();
		//	System.out.println("              vm create"+vm.getId()+" on host "+host.getId());
			result = true;
		} 
		else 
		{//kashav: if not able to allocate new host then assign previous host
			if (prevHost != null) 
			{
				prevHost.vmCreate(vm);
				host.updateVmsProcessing(0);
			}
			result = false;
		}
		//Log.setDisabled(false);
		return result;
	}

	public boolean assignVMtoHost(PowerVm vm, PowerHost host,PowerHost prevHost)
	{
		boolean result;
		
		if (prevHost != null) 
		{
			prevHost.vmDestroy(vm);
			//System.out.println("              vm destroy"+vm.getId()+" on host "+prevHost.getId());
		}
		Log.setDisabled(true);
		if (host.vmCreate(vm)) 
		{
		//	gen.put(vm.getId(), host);
			host.updateVmsProcessing(0);
			result = true;
		} 
		else 
		{//kashav: if not able to allocate new host then assign previous host
			if (prevHost != null) 
			{
				prevHost.vmCreate(vm);
				host.updateVmsProcessing(0);
			}
			result = false;
		}
		//Log.setDisabled(false);
		return result;
	}

	public PowerHost findRandomHost(PowerVm vm) 
	{
		//System.out.println(" hosts size "+hosts.size());
		
		Collections.shuffle(hosts, rnd);
		
		for (PowerHost host : hosts) 
		{
			//System.out.print(" Host "+host.getId()+" is not suitable");
			if (host.isSuitableForVm(vm))
			{
				//System.out.println("       Host is suitable for vm"+vm);
				return host;
			}
		}

		return null;
	}
	
	
}
	
	/*
	 * public int numberOfHosts() { int n=0; for(PowerHost host:hosts) { n++; }
	 * return n; }
	 * 
	 * public int numberOfVms() { int m=0; for(PowerVm VM:vmList) { m++; } return m
	 * ; }
	 * 
	 * public float getAvgCpuUtil() { int p; int m=numberOfVms(); int
	 * n=numberOfHosts(); float sum=(float) 0.00;
	 * 
	 * for(PowerHost host:hosts) { if(host.getPower()!=0.0) { sum+=getUtilfCpu(1,m);
	 * } else { sum=0; } } float avgUtilCpu=sum/n; return avgUtilCpu; }
	 * 
	 * public float getUtilfCpu(int p,int m) { float sum=(float) 0.0; for (PowerVm
	 * vm : vmList) { Host oldHost = findVmByID(vm.getId(), originalVMs).getHost();
	 * if (oldHost.getId() == vm.getHost().getId()) { int v=1;
	 * sum+=v*getUtilCpuParticular(p,v); } else { sum=0; } } float CpuUtil=p*sum/m;
	 * return CpuUtil; }
	 * 
	 * public float getUtilCpuParticular(int p ,int v) { float particularCpuUtil;
	 * for(PowerHost host:hosts) { for(PowerVm VM:vmList) {
	 * particularCpuUtil=p*v*((/timeCPU(p))+(/timeCPU(p)))*100; }
	 * 
	 * }
	 * 
	 * }
	 * 
	 * public float timeCPU(int p) {
	 * 
	 * return p*(/); }
	 * 
	 * /////////////////////////////////////////////////////////////////////////////
	 * //////////////////
	 * 
	 * public float getAvgMemUtil() { int p; int m=numberOfVms(); int
	 * n=numberOfHosts(); float sum=(float) 0.00;
	 * 
	 * for(PowerHost host:hosts) { if(host.getPower()==0.0) { sum+=getUtilMem(1,m);
	 * } else { sum=0; } } float avgUtilMem=sum/n; return avgUtilMem; }
	 * 
	 * public float getUtilMem(int p,int m) { float sum=(float) 0.0; for (PowerVm vm
	 * : vmList) { Host oldHost = findVmByID(vm.getId(), originalVMs).getHost(); if
	 * (oldHost.getId() == vm.getHost().getId()) { int v=1;
	 * sum+=v*getUtilMemParticular(p,v); } else { sum=0; } } float MemUtil=p*sum/m;
	 * return MemUtil; }
	 * 
	 * public float getUtilCpuParticular(int p ,int v) { float particularCpuUtil;
	 * for(PowerHost host:hosts) { for(PowerVm VM:vmList) {
	 * particularCpuUtil=p*v*((/))*100; }
	 * 
	 * }
	 * 
	 * 
	 * /////////////////////////////////////////////////////////////////////////////
	 * ///////////////////////////
	 * 
	 * 
	 * public float totalEnergy() { int p; for(PowerHost host:hosts) {
	 * if(host.getPower()==0.0) { energy+=totaleng(1,m); } else { energy=0; } }
	 * return energy; }
	 * 
	 * public float totaleng(int p,int m) { float Peng=0; float sum=(float) 0.0; for
	 * (PowerVm vm : vmList) { Host oldHost = findVmByID(vm.getId(),
	 * originalVMs).getHost(); if (oldHost.getId() == vm.getHost().getId()) { int
	 * v=1; Peng+=p*getEnegParticular(p,v); } else { sum=0; } } return Peng; }
	 * 
	 * public double getEnegParticular(int p,int v) { double particularEng = 0;
	 * for(PowerHost host:hosts) { for(PowerVm VM:vmList) {
	 * particularEng=p*v*(host.getPower()+(host.getMaxPower()-host.getPower())*v); }
	 * 
	 * } return particularEng; }
	 * 
	 */
	
	



