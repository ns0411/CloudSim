/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009-2012, The University of Melbourne, Australia
 */

package org.cloudbus.cloudsim.power.lists;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.lists.HostList;
import org.cloudbus.cloudsim.lists.VmList;
import org.cloudbus.cloudsim.power.MultiGA;
import org.cloudbus.cloudsim.power.PowerHost;
import org.cloudbus.cloudsim.power.PowerVmAllocationPolicyMigrationMGA;

/**
 * PowerVmList is a collection of operations on lists of power-enabled VMs.
 * 
 * If you are using any algorithms, policies or workload included in the power package, please cite
 * the following paper:
 * 
 * Anton Beloglazov, and Rajkumar Buyya, "Optimal Online Deterministic Algorithms and Adaptive
 * Heuristics for Energy and Performance Efficient Dynamic Consolidation of Virtual Machines in
 * Cloud Data Centers", Concurrency and Computation: Practice and Experience (CCPE), Volume 24,
 * Issue 13, Pages: 1397-1420, John Wiley & Sons, Ltd, New York, USA, 2012
 * 
 * @author Anton Beloglazov
 * 
 * @author Anton Beloglazov
 * @since CloudSim Toolkit 2.0
 */
public class SolutionVectorList extends MultiGA {

	public SolutionVectorList(PowerVmAllocationPolicyMigrationMGA CSA,
			List<PowerHost> originalHosts1, int id1) throws Exception {
		super(CSA, originalHosts1, id1);
		// TODO Auto-generated constructor stub
	}

	/**
	 * Sort by cpu utilization.
	 * 
	 * @param vmList the vm list
	 */
	public static <T extends MultiGA> void sortSolutionVectorListByWtoP(List<T> SolutionVectorList)
	{
		Collections.sort(SolutionVectorList, new Comparator<T>() 
		{

			@Override
			public int compare(T a, T b) throws ClassCastException 
			{
				double[] aUtilization = a.getFitness();
				Double A=aUtilization[3];
				double[] bUtilization = b.getFitness();
				Double B=bUtilization[3];
				return B.compareTo(A);
			}
		});
	}
	
	public static <T extends MultiGA> void sortSolutionVectorListByPowerIncreasing(List<T> SolutionVectorList)
	{
		Collections.sort(SolutionVectorList, new Comparator<T>() 
		{

			@Override
			public int compare(T a, T b) throws ClassCastException 
			{
				double[] aUtilization = a.getFitness();
				Double A=aUtilization[4];
				double[] bUtilization = b.getFitness();
				Double B=bUtilization[4];
				return A.compareTo(B);
			}
		});
	}

		
	/*
	public static <T extends Host> void sortByHostPower(List<T> HostList)
	{
		Collections.sort(HostList, new Comparator<T>() 
		{

			@Override
			public int compare(T a, T b) throws ClassCastException 
			{
				Double aUtilization = a.;
				Double bUtilization = b.getAvailableMips();
				return bUtilization.compareTo(aUtilization);
			}
		});
	}
*/
	/*
	public static <T extends Vm> void sortByAvailableMips(List<T> HostList)
	{
		Collections.sort(HostList, new Comparator<T>() 
		{

			@Override
			public int compare(T a, T b) throws ClassCastException 
			{
				Double aUtilization = a.getTotalUtilizationOfCpuMips(CloudSim.clock());
				Double bUtilization = b.getTotalUtilizationOfCpuMips(CloudSim.clock());
				return bUtilization.compareTo(aUtilization);
			}
		});
	}
	*/


}