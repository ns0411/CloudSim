package org.cloudbus.cloudsim.power.lists;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.lists.HostList;
import org.cloudbus.cloudsim.lists.VmList;
import org.cloudbus.cloudsim.power.PowerHost;

/**
 * PowerVmList is a collection of operations on lists of power-enabled VMs.
 * 
 * If you are using any algorithms, policies or workload included in the power package, please cite
 * the following paper:
 * 
 * Anton Beloglazov, and Rajkumar Buyya, "Optimal Online Deterministic Algorithms and Adaptive
 * Heuristics for Energy and Performance Efficient Dynamic Consolidation of Virtual Machines in
 * Cloud Data Centers", Concurrency and Computation: Practice and Experience (CCPE), Volume 24,
 * Issue 13, Pages: 1397-1420, John Wiley & Sons, Ltd, New York, USA, 2012
 * 
 * @author Anton Beloglazov
 * 
 * @author Anton Beloglazov
 * @since CloudSim Toolkit 2.0
 */
public class PowerHostList extends HostList {

	/**
	 * Sort by cpu utilization.
	 * 
	 * @param vmList the vm list
	 */
	public static <T extends PowerHost> void sortByHostAvailableMips(List<T> HostList)
	{
		Collections.sort(HostList, new Comparator<T>() 
		{

			@Override
			public int compare(T a, T b) throws ClassCastException 
			{
				Double aUtilization = a.getAvailableMips();
				Double bUtilization = b.getAvailableMips();
				return bUtilization.compareTo(aUtilization);
			}
		});
	}
	
	public static <T extends PowerHost> void sortIncresingByHostMipsUtilization(List<T> HostList)
	{
		Collections.sort(HostList, new Comparator<T>() 
		{

			@Override
			public int compare(T a, T b) throws ClassCastException 
			{
				Double a_allocatedHost=a.getTotalMips()-a.getAvailableMips();
				Double a_mipsUtilization=a_allocatedHost/a.getTotalMips();
				Double b_allocatedHost=b.getTotalMips()-b.getAvailableMips();
				Double b_mipsUtilization=b_allocatedHost/b.getTotalMips();
				return a_mipsUtilization.compareTo(b_mipsUtilization);
				//return b_mipsUtilization.compareTo(a_mipsUtilization);
			}
		});
	}

	public static <T extends PowerHost> void sortDecreasingByHostMipsUtilization(List<T> HostList)
	{
		Collections.sort(HostList, new Comparator<T>() 
		{

			@Override
			public int compare(T a, T b) throws ClassCastException 
			{
				Double a_allocatedHost=a.getTotalMips()-a.getAvailableMips();
				Double a_mipsUtilization=a_allocatedHost/a.getTotalMips();
				Double b_allocatedHost=b.getTotalMips()-b.getAvailableMips();
				Double b_mipsUtilization=b_allocatedHost/b.getTotalMips();
				//return a_mipsUtilization.compareTo(b_mipsUtilization);
				return b_mipsUtilization.compareTo(a_mipsUtilization);
			}
		});
	}
	
	
	
	/*
	public static <T extends Host> void sortByHostPower(List<T> HostList)
	{
		Collections.sort(HostList, new Comparator<T>() 
		{

			@Override
			public int compare(T a, T b) throws ClassCastException 
			{
				Double aUtilization = a.;
				Double bUtilization = b.getAvailableMips();
				return bUtilization.compareTo(aUtilization);
			}
		});
	}
*/
	/*
	public static <T extends Vm> void sortByAvailableMips(List<T> HostList)
	{
		Collections.sort(HostList, new Comparator<T>() 
		{

			@Override
			public int compare(T a, T b) throws ClassCastException 
			{
				Double aUtilization = a.getTotalUtilizationOfCpuMips(CloudSim.clock());
				Double bUtilization = b.getTotalUtilizationOfCpuMips(CloudSim.clock());
				return bUtilization.compareTo(aUtilization);
			}
		});
	}*/
	
}