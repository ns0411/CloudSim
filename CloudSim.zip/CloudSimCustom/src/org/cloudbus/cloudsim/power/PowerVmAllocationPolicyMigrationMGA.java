package org.cloudbus.cloudsim.power;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.PrimitiveIterator.OfDouble;

import org.apache.commons.math3.stat.descriptive.moment.Skewness;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Host.hostType;
import org.cloudbus.cloudsim.HostStateHistoryEntry;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmScheduler;
import org.cloudbus.cloudsim.VmSchedulerSpaceShared;
import org.cloudbus.cloudsim.VmSchedulerTimeShared;
import org.cloudbus.cloudsim.VmSchedulerTimeSharedOverSubscription;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.power.lists.PowerHostList;
import org.cloudbus.cloudsim.power.lists.PowerVmList;
import org.cloudbus.cloudsim.power.lists.SolutionVectorList;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;
import org.cloudbus.cloudsim.util.ExecutionTimeMeasurer;
import org.w3c.dom.events.MutationEvent;

import java.util.logging.Logger;


public class PowerVmAllocationPolicyMigrationMGA extends PowerVmAllocationPolicyMigrationAbstract
{
	
	public static Random rnd;
	List<MultiGA> initialPop,pop,excludedPop,clonePopulation,newClonedPopulation,pareto; 
	int population_Size=10; 
    double hotUtilization=1;
    double warmUtilization=.85;
    double coldUtilization=.60;
    private final List<Map<String, Object>> savedAllocation = new ArrayList<Map<String, Object>>();
    List<Host> hostListOriginal=new ArrayList<Host>();
   	public PowerVmAllocationPolicyMigrationMGA(List<? extends Host> hostList,
			PowerVmSelectionPolicy vmSelectionPolicy) 
	{
		super(hostList, vmSelectionPolicy);
		// TODO Auto-generated constructor stub
		Log.printLine("\n ********************* Starting Algorithm **********************\n ");
		//Log.enable();
		//Log.setDisabled(true);
	}
   	protected List<Map<String, Object>> getSavedAllocation() {
		return savedAllocation;
	}
   
   	protected void saveAllocation() 
	{
		getSavedAllocation().clear();
		for (Host host : getHostList()) 
		{
			for (Vm vm : host.getVmList())
			{
				if (host.getVmsMigratingIn().contains(vm))
				{
					//System.out.println(" Vm is in migratingin "+vm.getId());
					continue;
				}
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("host", host);
				map.put("vm", vm);
				getSavedAllocation().add(map);
			//	System.out.println(" Save Allocation,vm "+vm.getId()+" host "+host.getId());
			}
		}
	}
	public List<Map<String, Object>> optimizeAllocation(List<? extends Vm> vmList) 
	{
		
		ExecutionTimeMeasurer.start("optimizeAllocationTotal");
		ExecutionTimeMeasurer.start("optimizeAllocationHostSelection");
		List<PowerHostUtilizationHistory> overUtilizedHosts = getOverUtilizedHosts();
		getExecutionTimeHistoryHostSelection().add(
				ExecutionTimeMeasurer.end("optimizeAllocationHostSelection"));
		System.out.println("oveutlilized host size"+overUtilizedHosts.size());
		printOverUtilizedHosts(overUtilizedHosts);
		//printGetHostList("Initial Mapping");
		saveAllocation();
		
		ExecutionTimeMeasurer.start("optimizeAllocationVmSelection");
		if(overUtilizedHosts.size()!=0)
		{
			changeHostStateFromHotTOGreenByMigratingVMs(overUtilizedHosts);
		}
	
		getExecutionTimeHistoryVmSelection().add(ExecutionTimeMeasurer.end("optimizeAllocationVmSelection"));
		
		Log.printLine("Reallocation of VMs from the over-utilized hosts:");
		ExecutionTimeMeasurer.start("optimizeAllocationVmReallocation");
		
		System.out.println("oveutlilized host size"+overUtilizedHosts.size());
		
		List<Map<String, Object>> migrationMap=getNewVmPlacement(new HashSet<Host>(overUtilizedHosts));
				
		//restoreAllocation();
		getExecutionTimeHistoryVmReallocation().add(
		ExecutionTimeMeasurer.end("optimizeAllocationVmReallocation"));
		Log.printLine();
		Log.enable();
		//restoreAllocation();
		getExecutionTimeHistoryTotal().add(ExecutionTimeMeasurer.end("optimizeAllocationTotal"));
		//printMappingMigrationMap(migrationMap);
		return migrationMap;
	}
	
	protected List<Map<String, Object>> getNewVmPlacement(Set<? extends Host> excludedHosts1) 
	{
		
		//All host
		System.out.println("............... All host.................");
		
		double initialTotalTemp=0;
		int initialActiveHost=0;
		int totalVMs=0;
		double vmsTotalMipsReq=0;
		boolean isAnyColdHost=false;
		
		for(PowerHost ph:this.<PowerHost>getHostList())
		{
			
			if(ph.getAvailableMips()!=ph.getTotalMips())
			{
				initialTotalTemp+=ph.getPower();
				initialActiveHost++;
			}
			ph.setHostType();
			if(ph.getAvailableMips()==ph.getTotalMips())
			{
				continue;
			}
			if(ph.getMipsUtilization()<=coldUtilization && (ph.getAvailableMips()!=ph.getTotalMips()))
			{
				//System.out.println(" cold host");
				isAnyColdHost=true;
			}
			System.out.println(" Host id "+ph.getId()+" mips uti "+ph.getMipsUtilization()+ " host state "+ph.getHostType()+" total mips "+ph.getTotalMips()+
					" avai mips "+ph.getAvailableMips());
			double totalCurrentMipsRequirementByVM=0;
			System.out.println();
			for(Vm pv:ph.getVmList())
			{	totalVMs++;
				vmsTotalMipsReq+=pv.getCurrentRequestedMaxMips();
				totalCurrentMipsRequirementByVM+=pv.getCurrentRequestedMaxMips();
				System.out.print("  vm id "+pv.getId());//+" mips req"+pv.getCurrentRequestedMaxMips());
				if(pv.getHost()==null)
				{
					pv.setHost(ph);
				//	System.out.println(" Setting host ");
				}
			}
			//System.out.println(" totalCurrentMipsRequirementByVM "+totalCurrentMipsRequirementByVM);
			System.out.println();
		
		}
		
		System.out.println(" initialActiveHost "+initialActiveHost+" totalVMs "+totalVMs+" vmsTotalMipsReq "+vmsTotalMipsReq);
		
		if(!isAnyColdHost)
		{
			System.out.println("******************* No coldHost*******************");
			return null;
		}
			
		System.out.println("       Overutilized host"+excludedHosts1.size());
		
		//Select VMs from overutilized host and migrate on green state host
		
		List<PowerHost> ph1=new ArrayList<PowerHost>();
		
		for(Host h:excludedHosts1)
		{
			ph1.add((PowerHost) h);
		}
		
		List<PowerHost> switchedOffHosts = getSwitchedOffHosts();
		System.out.println("       switchedOffHosts "+switchedOffHosts.size());
		
		// over-utilized hosts + Switched off host
		Set<PowerHost> excludedHostsForFindingUnderUtilizedHost = new HashSet<PowerHost>();
		excludedHostsForFindingUnderUtilizedHost.addAll(ph1);
		excludedHostsForFindingUnderUtilizedHost.addAll(switchedOffHosts);
		
		List<PowerHost> hostForPop=new ArrayList<PowerHost>();
		for (PowerHost host : this.<PowerHost> getHostList()) 
		{
			if (excludedHostsForFindingUnderUtilizedHost.contains(host))
			{
				continue;
			}
			
			hostForPop.add(host);
		
		}
		
		//hostForPop contains all host that are neither overloaded nor switchedOff
		if(hostForPop.size()<=1)
		{
			//Host is only hot or sleep
			System.out.println("*******************Number of Host are less either 0 or 1 for population******************* ");
			return null;
		}
		
		System.out.println(" Number of host for initial solution vector "+hostForPop.size());
		rnd = new Random(); //for random number
		pop = new ArrayList<MultiGA>();

		System.out.println("---------- Creating Initial Population Randomly----------");
		initialPop=new ArrayList<MultiGA>();
		for (int i = 1; i <= population_Size; i++) // 
		{
			try 
			{
				initialPop.add(new MultiGA(this,hostForPop,i));
			//	System.out.println(" Solution Vector Creation Complete ");
				System.out.println("---------- Solution Vector "+i+" created ----------");
			} 
			catch (Exception e) 
			{
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
		}
		//If population is not created then return null;
		if(initialPop.size()==0)
		{
			return null;
		}
	
		int count=0;
		
		
		
		for (int i = 0; i < population_Size; i++)
		{
			pareto =crossover(initialPop);
		}
		
		//iMPORTANT FUNCTION CALLING
		MultiGA solutionVector=mutation(CSA(pareto));
			//solutionVector=bestSolutionSoFar(tempPop);
		System.out.println(" Best Solution Vector in iteration "+count+" is "+solutionVector);
		int totoalActiveHostInSolutionVector=printTotalPowerAndActiveHost(solutionVector);
		System.out.println(" initialTotalTemp "+initialTotalTemp+" initialActiveHost "+initialActiveHost);
		if(totoalActiveHostInSolutionVector==initialActiveHost)
		{
			return null;
		}
		//Making Copy of original host
		List<Host> originalHostList=new ArrayList<Host>();
		originalHostList=copyOrignalHost();
		
		//copy Host from PowerHostList to PowerHostHistoryList(orignal host list is needed in migration) 
	
		copyPowerHostListIntoPowerHostHistory(solutionVector);
		migrationMap1.clear();
		for(Host ph:this.getHostList())
		{
			ph=removeCommonVMs(ph,originalHostList);
			for(Vm vm:ph.getVmList())
			{
				addToMigrationMap(vm,ph);
			}
		}
		restoreAllocation();
		return migrationMap1;
	}
	
	public Host removeCommonVMs(Host host,List<Host> originalHostList)
	{
		List<Vm> vmToRemove=new ArrayList<Vm>();
		for(Host ph:originalHostList)
		{
			if(host.getId()==ph.getId())
			{
				for(Vm vm:host.getVmList())
				{
					for(Vm vmOriginal:ph.getVmList())
					{
						if(vm.getId()==vmOriginal.getId())
						{
							vmToRemove.add(vm);
						}
					}
				}
			}
		}
		
		for(Vm vm:vmToRemove)
		{
			host.getVmList().remove(vm);
		}
		return host;
	}
	
	public void copyPowerHostListIntoPowerHostHistory(MultiGA ind)
	{
		//empty PowerHostHistory
		for(Host ph:this.getHostList())
		{
			ph.vmDestroyAll();
		}
		for(PowerHost host:ind.hosts)
		{
			for(Host ph:this.getHostList())
			{
				if(host.getId()==ph.getId())
				{
					for(Vm vm:host.getVmList())
					{
						ph.vmCreate(vm);
					}
					//hostListOriginal.add(ph);
					break;
				}
			}
		}
		
	}
	
	public List<Host> copyOrignalHost()
	{
		List<Host> clone = new ArrayList<Host>();
	    for (Host item : this.getHostList())
	    	{
	    		
					clone.add(copyHost(item));
	    	}	
	    return clone;
		
	}
	
	public Host copyHost(Host host) 
	{
		VmScheduler sch = host.getVmScheduler(), newSch;
		if (sch instanceof VmSchedulerTimeShared)
		{
			newSch = new VmSchedulerTimeShared(host.getPeList());
		} 
		else if (sch instanceof VmSchedulerTimeSharedOverSubscription)
		{
			newSch = new VmSchedulerTimeSharedOverSubscription(
					host.getPeList());
		} 
		else 
		{
			newSch = new VmSchedulerSpaceShared(host.getPeList());
		}

		Host newHost=new Host(host.getId(), 
				 new RamProvisionerSimple(host.getRam()),
				 new BwProvisionerSimple(host.getBw()),
				 host.getStorage(), 
				 host.getPeList(), 
				 newSch);
		
		for(Vm vm:host.getVmList())
		{
			newHost.vmCreate(vm);
		}
		return newHost;
	}
	
	public MultiGA copyClone(MultiGA ind) 
	{
		MultiGA newClone=new MultiGA(this,ind.originalVMs,ind.vmList,ind.originalHosts,ind.hosts,ind.fitness);	
		
		return newClone;
	}

	
	public void printHostList(List<Host> hostList)
	{
		for(Host ph:hostList)
		{
			System.out.println(" Host "+ph.getId());
			for(Vm vm:ph.getVmList())
			{
				System.out.print(" VM "+vm.getId());
			}
			System.out.println();
		}
	}
	
	public void printGetHostList(String s)
	{
		System.out.println(s);
		for(PowerHost ph:this.<PowerHost>getHostList())
		{
			if(ph.getTotalMips()==ph.getAvailableMips())
			{
				continue;
			}
			System.out.println(" Host id "+ph.getId()+" host is "+ph);//+" mips uti "+ph.getMipsUtilization()+
			//" host state "+ph.getHostType());
			
			//System.out.println();
			for(Vm pv:ph.getVmList())
			{	
				System.out.print("  vm id "+pv.getId());//+" mips req"+pv.getCurrentRequestedMaxMips());
			}
			//System.out.println(" totalCurrentMipsRequirementByVM "+totalCurrentMipsRequirementByVM);
			System.out.println();
		
		}
	}
	protected void restoreAllocation() 
	{
		for (Host host : this.getHostList()) 
		{
			host.vmDestroyAll();
		//	System.out.println(" Destroying all Vms from host "+host.getId());
			host.reallocateMigratingInVms();
		}
		for (Map<String, Object> map : getSavedAllocation())
		{
			Vm vm = (Vm) map.get("vm");
			PowerHost host = (PowerHost) map.get("host");
			if (!host.vmCreate(vm)) 
			{
				Log.printLine("Couldn't restore VM #" + vm.getId() + " on host #" + host.getId());
				System.exit(0);
			}
		//	System.out.println(" Restore allocation,vm "+vm.getId()+" host "+host.getId());
			getVmTable().put(vm.getUid(), host);
		}
		
	}
	
	List<Map<String, Object>> migrationMap1 = new LinkedList<Map<String, Object>>();
	public void addToMigrationMap(Vm vm,Host host)
	{
		//vm.setHost(host);
		//if(vm.getHost().getId()==host.getId())
		//{return;}
		Map<String, Object> migrate = new HashMap<String, Object>();
		migrate.put("vm", vm);
		migrate.put("host",host);
		migrationMap1.add(migrate);
	}
	
	
	public int printTotalPowerAndActiveHost(MultiGA ind)
	{
		double totalPower=0;
		int totalActiveHost=0;
		for(PowerHost ph:ind.hosts)
		{
			if(ph.getAvailableMips()==ph.getTotalMips())
			{
				continue;
			}
			totalPower+=ph.getPower();
			totalActiveHost++;
			System.out.println(" host "+ph.getId()+" power "+ph.getPower());
			for(Vm vm:ph.getVmList())
			{
				System.out.print(" vm "+vm.getId());
			}
			System.out.println();
		}
		System.out.println("----------- Total Power and Active Host-----------"+totalPower+" and "+totalActiveHost);
		return totalActiveHost;
	}
	public void updatingFitnessValueInClonalSelectionInd(List<MultiGA> pop)
	{
		
		for(MultiGA ind:pop)
		{
			ind.fitness[4]=ind.fitness[4];
		}
	}
		
	public static <T extends MultiGA> void sortByPower(List<T> SolutionVectorList)
	{
		Collections.sort(SolutionVectorList, new Comparator<T>() 
		{

			@Override
			public int compare(T a, T b) throws ClassCastException 
			{
				//double[] aUtilization = a.getFitness();
				Double A=a.fitness[4];
				//double[] bUtilization = b.getFitness();
				Double B=b.fitness[4];
				return B.compareTo(A);
			}
		});
	}
	public static <T extends MultiGA> void sortByPowerIncreasing(List<T> SolutionVectorList)
	{
		Collections.sort(SolutionVectorList, new Comparator<T>() 
		{

			@Override
			public int compare(T a, T b) throws ClassCastException 
			{
				//double[] aUtilization = a.getFitness();
				Double A=a.fitness[4];
				//double[] bUtilization = b.getFitness();
				Double B=b.fitness[4];
				return A.compareTo(B);
			}
		});
	}	

public List<MultiGA> CSA(List<MultiGA> pop) 
{
		for(MultiGA ind:pop)
		{
			System.out.println("---------- Mutation Start for solution vector  "+ind.id+"----------");
			mutationClonedPopulation(ind);
			updateFitness(ind);
		}
		
		return pop;
	
	}

	public List<MultiGA> cloningPopulation(List<MultiGA> clonePopulation) 
	{
		newClonedPopulation=new ArrayList<MultiGA>();
		for(MultiGA ind:clonePopulation)
		{//cloning population based on normalize fitness
			//find new id for clone solution vector
			int newid=0;
			boolean flag;
			while(true)
			{
				flag=false;
				newid=getRandomNumberInRange(population_Size+1,10*population_Size);
				if(newClonedPopulation.size()!=0)
				{
					for(MultiGA indid:newClonedPopulation)
					{
						if(indid.id==newid)
						{
							flag=true;
							break;
						}
					}
				}
				if(!flag)
				{
					break;
				}
				System.out.println("Stuck in while loop");
			}

			//Perform cloning
			
			if(ind.fitness[5]==0)
			{	MultiGA cloneInd;
					//cloneInd = (ClonalSelectionInd) ind.clone();
					cloneInd = copyClone(ind);	
					cloneInd.id=newid;
					newClonedPopulation.add(cloneInd);
			}
			else 
			{
				double cloning=ind.fitness[5];
				for(double i=0;i<cloning;i++)
				{		
						//ClonalSelectionInd cloneInd=(ClonalSelectionInd) ind.clone();
						MultiGA cloneInd= copyClone(ind);
						cloneInd.id=newid+(int)i;
						newClonedPopulation.add(cloneInd);
				}
			}
		}	
		return newClonedPopulation;	
	}

	public List<MultiGA> preparingPopulationForCloning(List<MultiGA> pop)
	{
		double fitPowerMax=0,fitPowerMin=100000;
		for(MultiGA ind:pop)
		{
			double indFitness=ind.fitness[4];
		//	System.out.println("       Solution Vector "+" Power "+indFitness+" WTOP "+ind.fitness[3]);
			if(indFitness>fitPowerMax)
			{
				fitPowerMax=indFitness;
			}
			if(indFitness<fitPowerMin)
			{
				fitPowerMin=indFitness;
			}
		}
		
		//setting up normalize fitness
		for(MultiGA ind:pop)
		{
			double indFitness=ind.fitness[4];
			ind.fitness[5]=Math.ceil((indFitness-fitPowerMin)/(fitPowerMax-fitPowerMin)*10);
		}
		
		System.out.println();
		
		double percentOfPopultion=40;
		System.out.println(" Take " +percentOfPopultion +"% solution vector in Clone population from population based on best fitness");
		
		//Select best __% solution vector in clonePopulation
		clonePopulation=new ArrayList<MultiGA>();
		for(int i=0;i<(pop.size()*percentOfPopultion)/100;i++)
		{
			clonePopulation.add(pop.get(i));
			//clonePopulation.add(pop.get(i));
		}
		
		System.out.println("----------Best % solution vector in  ClonePopulation----------");
		int count=0;
		for(MultiGA ind:clonePopulation)
		{
			count++;
			System.out.println("       Solution Vector  id "+ind.id+" Power "+ind.fitness[4]+" WTOP "+ind.fitness[3]+" normalize fitness "+ind.fitness[5]);
		}
		System.out.println(" Clone population selected from population  is "+count);
		
		return clonePopulation;
	}
	
	public void mutationClonedPopulation(MultiGA ind)
	{// Goal is to increase number of Green host and minimize cold host
		Collections.shuffle(ind.hosts, rnd);
		for(PowerHost ph:ind.hosts)
		{
			if(ph.getAvailableMips()==ph.getTotalMips())
			{//skip host if zero utilization candidate for switched off
				continue;
			}
			double mipsUtilization=ph.getMipsUtilization();
			if(mipsUtilization<=coldUtilization)
			{
				tryTOMigrateAllVMsFromColdHost(ph, ind);
			}
		}
	}
	
	public void updateFitness(MultiGA ind) 
	{
		double totalPowerConsumed=0;
		for(PowerHost ph:ind.hosts)
		{
			if(ph.getAvailableMips()==ph.getTotalMips())
			{
				continue;
			}
			totalPowerConsumed+=ph.getPower();
		}
		ind.fitness[4]=totalPowerConsumed;
	}
	private static int getRandomNumberInRange(int min, int max) 
	{

		if (min >= max)
		{
			throw new IllegalArgumentException("max must be greater than min");
		}

		return (int)(Math.random() * ((max - min) + 1)) + min;
	}
	public void numberOfHotGreenColdHost(MultiGA ind)
	{
		int hot=0,green=0,cold=0,sleep=0;
		
		for(PowerHost ph:ind.hosts)
		{
			double mipsUtilization=ph.getMipsUtilization();
			if(ph.getAvailableMips()==ph.getTotalMips())
			{
				sleep++;
			}
			else if(mipsUtilization<=coldUtilization)
			{
				cold++;
			}
			else if(mipsUtilization>=hotUtilization)
			{
				hot++;
			}
			else 
			{
				green++;
			}
		}
	//	System.out.println("       Number of sleep "+sleep+ " cold "+cold+" green "+green+" hot "+hot);
	}
	
	public void tryTOMigrateAllVMsFromColdHost(PowerHost coldHost,MultiGA ind)
	{
		
		System.out.println("              Try to migrate all vms form host "+coldHost.getId()+" mips uti "+coldHost.getMipsUtilization());
		
		List<Vm> coldVmList=new ArrayList<Vm>();
		
		for(Vm vm:coldHost.getVmList())
		{
			System.out.println("              vm "+vm.getId());
			coldVmList.add(vm);
		}
		
		//System.out.println();
		boolean allVmsMigrated=false;
		
		
		SortedMap<Integer, PowerHost> map=new TreeMap<Integer,PowerHost>();//keeping mapping of VM to Host for roll back
		for(PowerHost ph1:ind.hosts)
		{
			List<Vm> vmTempList=new ArrayList<Vm>();
			if(coldHost==ph1 || (ph1.getAvailableMips()==ph1.getTotalMips()))
			{//skip same host or zero utilization host
				continue;
			}
			while(true)
			{
				Collections.shuffle(coldVmList, rnd);//Vms shuffled to get random mapping
				PowerVm vm=(PowerVm) coldVmList.get(0);//picking first vm
				//PowerVm vm=selectVmWithHigherAvailableMips(coldVmList);
				System.out.println("              vm "+vm.getId()+" try to migrate on host "+ph1.getId());
				double mipsUtilizationAfterVmAllocation=ph1.getMipsUtilization()+(vm.getCurrentRequestedMaxMips()/ph1.getTotalMips());
				if(ph1.isSuitableForVm(vm)&& mipsUtilizationAfterVmAllocation<hotUtilization)//checking for suitability
				{
					map.put(vm.getId(), ph1);
					ind.assignVMtoHost(vm, ph1,coldHost);
					vmTempList.add(vm);
					System.out.println("              vm "+vm.getId()+" is allocated to cold host"+ph1.getId()+" mips uti "+mipsUtilizationAfterVmAllocation);
				}
				
				else 
				{
					break;
				}
				for(Vm vm1:vmTempList)
				{	
					
					coldVmList.remove(vm1);
				}
				if(coldVmList.isEmpty())
				{
					allVmsMigrated=true;
					break;
				}
			}
			
			if(coldVmList.isEmpty())
			{//if all vms are reallocated then exit
				ind.getFitness();
				break;
			}	
		}
		
		if(!allVmsMigrated)
		{//If migration of all vms not possible then revert all migration operation
			Set<Map.Entry<Integer, PowerHost>> set=map.entrySet();
			for(Map.Entry<Integer, PowerHost> iter:set)
			{
				int vm_number=iter.getKey();
				PowerHost host=iter.getValue();
				PowerVm vm=findVmByIdOnHost(vm_number,host);
				System.out.println("              Revert migration decision vm "+vm.getId()+ " to host "+host.getId());
				ind.assignVMtoHost(vm,coldHost,host);
				ind.getFitness();
				
				
			}
		}
		
	}
	
	private void changeHostStateFromHotTOGreenByMigratingVMs(List<PowerHostUtilizationHistory> overUtilizedHosts) 
	{
		List<PowerVm> vmsFromHotHostList=new ArrayList<PowerVm>();
		for(Host ph:overUtilizedHosts)
		{
		//	System.out.println("host id "+ph.getId());
			while(ph.getMipsUtilization()>hotUtilization)
			{
				PowerVmList.sortByMipsUtilization(ph.getVmList());
				PowerVm vmId=(PowerVm) ph.getVmList().get(0);
				vmsFromHotHostList.add(vmId);
				ph.vmDestroy(vmId);
			//	System.out.println(" vm id "+vmId.getId()+" for migration");
			}
		//	System.out.println(" utilizaiton after removing vm"+ph.getMipsUtilization());
		}
		
		PowerHostList.sortDecreasingByHostMipsUtilization(this.<PowerHost>getHostList());
		for(PowerVm pv:vmsFromHotHostList)
		{
			boolean vmAllocatedToHost=false;
			for (PowerHost host : this.<PowerHost> getHostList())
			{
				//System.out.println(" host "+host.getId()+" host type"+host.getHostType());
				if(host.getMipsUtilization()>hotUtilization || host.getMipsUtilization()==0 )
				{
				//	System.out.println(" host is not suitable");
					continue;
				}
				if(host.isSuitableForVm(pv))
				{
					if(isHostIsNotRedStateAfterVmAllocation(host, pv))
					{
						host.vmCreate(pv);
					//	System.out.println(" vm "+pv.getId()+" is allocated to "+host.getId());
						vmAllocatedToHost=true;
						break;
					}
				}
				//System.out.println(" host is not suitable");
			}
			
			//If no suitable host found then allocated to any host except hot one
			if(!vmAllocatedToHost)
			{
				System.out.println(" Considering sleeping host also for vm allocation");
				for (PowerHost host : this.<PowerHost> getHostList())
				{
					//System.out.println(" host "+host.getId()+" host type"+host.getHostType());
					if(host.getMipsUtilization()>hotUtilization)
					{
						continue;
					}
					if(host.isSuitableForVm(pv))
					{
						if(isHostIsNotRedStateAfterVmAllocation(host, pv))
						{
							host.vmCreate(pv);
						//	System.out.println(" vm "+pv.getId()+" is allocated to "+host.getId());
							vmAllocatedToHost=true;
							break;
						}
					}
				}
			}
		}

	}
	
	private boolean isHostIsNotRedStateAfterVmAllocation(PowerHost ph,PowerVm vm)
	{
		boolean hostGreen=false;
		double totalMipsAfterVmAllocation=(ph.getTotalMips()-ph.getAvailableMips())+vm.getCurrentRequestedMaxMips();
		double mipsUtilization=totalMipsAfterVmAllocation/ph.getTotalMips();
		if(mipsUtilization<hotUtilization)
		{
			hostGreen=true;
		}
		return hostGreen;
	}
	
		private PowerVm findVmByIdOnHost(int id, PowerHost host) 
	{
		PowerVm vm=null;
		for(Vm vm1:host.getVmList())
		{
			if(vm1.getId()==id)
			{
				return (PowerVm)vm1;
			}
		}
		
		return null;

	}
	
	
	protected List<PowerHostUtilizationHistory> getOverUtilizedHosts() 
	{
		System.out.println("k Checking for overutilized host");
		List<PowerHostUtilizationHistory> overUtilizedHosts = new LinkedList<PowerHostUtilizationHistory>();
		for (PowerHostUtilizationHistory host : this.<PowerHostUtilizationHistory> getHostList()) {
			if (isHostOverUtilized(host)) 
			{	
				overUtilizedHosts.add(host);
			}
		}
		return overUtilizedHosts;
	}
	@Override
	protected boolean isHostOverUtilized(PowerHost host) 
	{
		hostType hType=host.getHostType();
		double mipsUtilization=host.getMipsUtilization();
		//to avoid overloaded host
		System.out.println(" host id"+host.getId()+" host type"+hType+
							" mips uti"+host.getMipsUtilization()+" total mips"+host.getTotalMips()
							+" avai mips "+host.getAvailableMips());
		if(hType.equals("hot") || mipsUtilization>hotUtilization )
		{
			System.out.println("K Utilization is more than"+ hotUtilization +"%");
			return true;
		}
		return false;
	}
	
	private MultiGA mutation(List<MultiGA> tempPop)
	{
		//System.out.println(" tempPop size "+tempPop.size());
		double bestPower=10000000;
		MultiGA temp1=null;
		//temp1=tempPop.get(0);
		for(MultiGA ind:tempPop)
		{
			//System.out.println(" ind "+ind.id+" power "+ind.fitness[4]);
			if(ind.fitness[4]<bestPower)
			{
				temp1=ind;
				bestPower=temp1.fitness[4];
			}
		}
		if(temp1!=null)
		{
			System.out.println("-------Best Solution Vecotr is "+temp1.id+" power "+temp1.fitness[4]+" WtoP "+temp1.fitness[3]+"---------");
		}	
		return temp1;
		
	}
	
	
	
	
	
	
	protected List<PowerHost> getOverUtilizedHosts(MultiGA ag) 
	{
		Log.printLine("inside getOverUtilizedHost function");
		List<PowerHost> overUtilizedHosts = new LinkedList<PowerHost>();
		List<PowerHost> tempHosts = new LinkedList<PowerHost>();
		
		for (PowerHost host : ag.hosts)
		{
			tempHosts.add(host);
		}
		int i;
		double maxTemperature=0;
		int maxHostID=0;
		int size = tempHosts.size();
		
			for (i=0 ; i< tempHosts.size(); i++){
				if(tempHosts.get(i).hotTemperatureOfServer() == 0)
				{
					System.out.println(" no utiliztion");
					continue;
				}
				if(tempHosts.get(i).getMipsUtilization()>hotUtilization)
				{
					overUtilizedHosts.add(tempHosts.get(i));
				}
				
				/*
				if( tempHosts.get(i).hotTemperatureOfServer() > maxTemperature)
				{
					maxTemperature= tempHosts.get(i).hotTemperatureOfServer() ;
					System.out.println("maxTemperature "+maxTemperature+" maxHostID"+i);
					maxHostID=i;
				}
				if (i == (size-1))
				{
					System.out.println("in exculed host"+tempHosts.get(maxHostID).getId());
					overUtilizedHosts.add(tempHosts.get(maxHostID));
					tempHosts.remove(maxHostID);
				}
				*/
			}
		
		return overUtilizedHosts;
	}
	
	
	
	private List<MultiGA> crossover(List<MultiGA> pop1) {
		MultiGA p1, p2;
	//	int len=pop.size();
	//	System.out.println(len);
		p1 = pop1.get(rnd.nextInt(pop1.size()));
		do {
			p2 = pop1.get(rnd.nextInt(pop1.size()));
		} while (p1.equals(p2));
		
		PowerVm temp=null;
		int crossoverPoint = rnd.nextInt(p1.hosts.get(0).getVmList().size());
		System.out.println(crossoverPoint);
		for(int i=0;i<crossoverPoint;i++)
		{
		 temp=(PowerVm) p1.vmList.get(i);
		 if(p2.hosts.get(i).isSuitableForVm(temp))
		{
		  p2.hosts.get(i).vmCreate(temp);
		  p1.hosts.get(i).vmDestroy(temp);
		  p2.hosts.get(i).updateVmsProcessing(0);
		  
		}
		}
	return pop1;
		}
	
	
	
	
	
}